# Data Structure

## BIT and Segment Tree
### Manipulation supports

| class          | Single setting | Single increment | Range setting | Range increment |
| -------------- | :------------: | :--------------: | :-----------: | :-------------: |
| BIT            |    Feasible    |       Yes        |      No       |       No        |
| RangeUpdateBIT |    Feasible    |     Feasible     |      No       |       Yes       |
| BIT2D          |    Feasible    |       Yes        |      No       |       No        |
| SegmentTree    |      Yes       |     Feasible     |      No       |       No        |