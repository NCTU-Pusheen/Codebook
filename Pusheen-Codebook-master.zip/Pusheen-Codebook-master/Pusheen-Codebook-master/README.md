# Pusheen's Codebook :3

Please help validate our codebooks. It would be better if you implement your program using this codebook and solve a problem. Once you get an AC, please leave a comment (inclusive of the problem ID where codes are validated) in [Pusheen's Check-book](https://docs.google.com/document/d/1pr3HO5QBLaZM3v-1qsNc9DoyPTS0N4SJkVFeeUCYFfg/edit).