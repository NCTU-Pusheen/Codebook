# Surroundings
Remind that shell is a very sensitive programming language. An extra space can lead to crashing.

## Update `.bashrc`
The file is located at `~/.bashrc`. You can omit Java, C or python lines if not needed. 

After the file is modified, you MUST invoke the new setting by:
```sh
source ~/.bashrc
```

## Update `.vimrc`
After the file is modified, you MUST invoke the new setting by:
```sh
source ~/.vimrc
```